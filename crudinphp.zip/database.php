<?php

$Picture=$_POST['Picture'];
$Firstname=$_POST['Firstname'];
$Lastname=$_POST['Lastname'];
$Email=$_POST['Email'];
$Telephone=$_POST['Telephone'];
$Gender=$_POST['Gender'];
$Nationality=$_POST['Nationality'];
$Username=$_POST['Username'];
$Password=$_POST['Password'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
 

    $sql = "INSERT INTO crud( Picture,Firstname,Lastname, Email,Telephone,Gender,Nationality,Password) 
    VALUES ('$Picture','$Firstname','$Lastname','$Email','$Telephone','$Gender','$Nationality','$Username','$Password')";
    if (mysqli_query($conn, $sql)) {
        echo 'sucessfully inserted data';
    } 
    else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}

?>