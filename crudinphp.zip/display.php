<?php
$DB_server="localhost";
$DB_user_name="root";
$DB_password="";
$DB_name="user";

$connect=mysqli_connect($DB_server,$DB_user_name,$DB_password,$DB_name);
$query = mysqli_query($connect, "SELECT * FROM crud");
echo"<table><tr><th>Picture</th><th>Firstname</th><th>Lastname</th><th>Email</th><th>Telephone</th><th>Gender</th><th>Nationality</th><th>Password</th></tr>";
while ($row = mysqli_fetch_assoc($query)) {
    $url='uploaded/'.$row["Profile"];
echo"
<tr>
<td><img src= './$url' class='image' alt=''></td>
<td>".$row["Firstname"]."</td>
<td>".$row["Lastname"]."</td>
<td>".$row["Email"]."</td>
<td>".$row["Telephone"]."</td>
<td>".$row["Gender"]."</td>
<td>".$row["Nationality"]."</td>
<td>".$row["Username"]."</td>
<td>".$row["Password"]."</td>
</tr";
}
echo "</table>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
        table,tr,th{
            border: 1px solid;
        }
        table,tr,td{
            border: 1px solid;
            color: indigo;
        }
        table{
            border-collapse: collapse;
        }
        .image{
            height: 80px;
            width: 60px;
            border-radius: 100%;
        }
    </style>
</head>
<body>
</body>
</html>